dtw
===

DTW (Dynamic Time Warping) python module


Examples are available as notebook:

* [a simple example](http://nbviewer.ipython.org/github/pierre-rouanet/dtw/blob/master/simple%20example.ipynb)
* [a sound comparison based on DTW + MFCC](http://nbviewer.ipython.org/github/pierre-rouanet/dtw/blob/master/MFCC%20%2B%20DTW.ipynb)
* [simple speech recognition](http://nbviewer.ipython.org/github/pierre-rouanet/dtw/blob/master/speech-recognition.ipynb)
